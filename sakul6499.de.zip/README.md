# Sakul6499.de
## Source code of my website :)

# Credits
This website is based on [Bulma] and the [Bulma-Start] project.  
The icons are mostly from [Simple-Icons], though all are modified and optimized by myself and some are freshly created!

## Copyright and license
Code copyright 2019 Lukas Weber. 
Code released under [the MIT license](https://github.com/jgthms/bulma-start/blob/master/LICENSE).




[Bulma]: http://bulma.io
[Bulma-Start]: https://github.com/jgthms/bulma-start
[Simple-Icons]: https://github.com/simple-icons/simple-icons