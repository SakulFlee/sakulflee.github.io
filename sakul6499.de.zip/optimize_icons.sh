#!/bin/bash
svgo --recursive --quiet --multipass --folder=icons
